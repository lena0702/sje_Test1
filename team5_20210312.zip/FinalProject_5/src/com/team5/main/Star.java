package com.team5.main;

public class Star {
	private String title;
	private String userid;

	public Star() {
		// TODO Auto-generated constructor stub
	}

	public Star(String title, String userid) {
		super();
		this.title = title;
		this.userid = userid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
}
